package testeaula01;

/**
 *
 * @author fabio
 */
public class TesteAula01 {
    public static void main(String[] args) {
        System.out.println("ola netbeans!");
    }
    
}
